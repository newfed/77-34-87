<?php

// ------------------------------------------------- //
  #                 BY: @blue_prints              #
  #             F#ck you credit changer :)        #
  # Change credit if you dont know how to code :) #
  #################################################
// -------------------------------------------------//


//important details
$emailzz = "jacvbghyujkiolpwemk675@gmail.com"; // your email
$salt = "22su33556"; // Txt File name

// To turn zsec off goto zsec-config.php

//important on/off
$d_log = "on"; // double login

$savetxt = "on";  //to save text file

$tgresult = "on"; // to recieve result on tg
?>