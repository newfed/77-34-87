<?php

$settings = array(
	"chat_id"		=> "1088205830",	// Chat ID Of You
	"bot_url"		=> "bot5252132779:AAHUEJBawGkG95uSg2BYVOOIzCTTlnxxem8",	// Your Bot API Key (ADD "bot" BEFORE API KEY)
);
return $settings;

?>