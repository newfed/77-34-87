<?php
  	require 'bot_fucker/fucker001.php';
	require 'bot_fucker/fucker002.php';
	require 'bot_fucker/fucker003.php';
	require 'bot_fucker/fucker004.php';
	require 'bot_fucker/fucker005.php';
	require 'bot_fucker/fucker006.php';
	require 'bot_fucker/fucker007.php';
	require 'bot_fucker/fucker008.php';
	exit(header("Location: ../index.php")); 
?>
